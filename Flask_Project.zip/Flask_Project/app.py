from flask import Flask, render_template, redirect, flash, url_for
from forms import RegistrationForm

app = Flask(__name__)

app.config['SECRET_KEY'] = 'secret123'


@app.route('/')
def home():

    events = [
        'Python Workshop',
        'Cybersecurity Forum',
        'AI Conference'
    ]

    return render_template(
        'home.html',
        title='Реєстрація на події',
        participants=150,
        events=events
    )


@app.route('/events')
def events():

    events = [
        'Python Workshop',
        'Cybersecurity Forum',
        'AI Conference'
    ]

    return render_template(
        'events.html',
        title='Список подій',
        events=events
    )


@app.route('/register', methods=['GET', 'POST'])
def register():

    form = RegistrationForm()

    if form.validate_on_submit():

        flash('Реєстрація успішно виконана!')

        return redirect(url_for('home'))

    return render_template(
        'register.html',
        form=form
    )


if __name__ == '__main__':
    app.run(debug=True)
