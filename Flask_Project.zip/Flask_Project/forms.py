from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, TextAreaField, SubmitField
from wtforms.fields import EmailField
from wtforms.validators import DataRequired, Length, Email, ValidationError


class RegistrationForm(FlaskForm):

    name = StringField(
        "Ім'я",
        validators=[
            DataRequired(),
            Length(max=50)
        ]
    )

    email = EmailField(
        "Електронна пошта",
        validators=[
            DataRequired(),
            Email()
        ]
    )

    category = SelectField(
        "Тип події",
        choices=[
            ('workshop', 'Воркшоп'),
            ('conference', 'Конференція')
        ]
    )

    message = TextAreaField(
        "Повідомлення",
        validators=[
            DataRequired()
        ]
    )

    submit = SubmitField('Надіслати')

    def validate_message(self, field):

        if len(field.data.split()) < 3:

            raise ValidationError(
                'Повідомлення повинно містити мінімум 3 слова'
            )
