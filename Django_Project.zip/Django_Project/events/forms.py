from django import forms

class RegistrationForm(forms.Form):

    name = forms.CharField(
        label="Ім'я",
        max_length=50
    )

    email = forms.EmailField(
        label="Електронна пошта"
    )

    category = forms.ChoiceField(
        label="Тип події",
        choices=[
            ('workshop', 'Воркшоп'),
            ('conference', 'Конференція')
        ]
    )

    message = forms.CharField(
        label="Повідомлення",
        widget=forms.Textarea
    )

    def clean_message(self):
        message = self.cleaned_data['message']

        if len(message.split()) < 3:
            raise forms.ValidationError(
                'Повідомлення має містити щонайменше 3 слова'
            )

        return message
