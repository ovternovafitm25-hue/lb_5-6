from .forms import RegistrationForm
from django.shortcuts import redirect
from django.shortcuts import render
from django.contrib import messages

def home(request):
    context = {
        'title': 'Реєстрація на події',
        'participants': 150,
        'events': [
            'Python Workshop',
            'Cybersecurity Forum',
            'AI Conference'
        ]
    }
    return render(request, 'home.html', context)

def event_list(request):
    context = {
        'title': 'Список подій',
        'participants': 150,
        'events': [
            'Python Workshop',
            'Cybersecurity Forum',
            'AI Conference'
        ]
    }
    return render(request, 'events.html', context)

def register(request):

    if request.method == 'POST':
        form = RegistrationForm(request.POST)

        if form.is_valid():
            messages.success(
                request,
                'Реєстрація успішно виконана!'
            )
            return redirect('/')

    else:
        form = RegistrationForm()

    return render(
        request,
        'register.html',
        {'form': form}
    )
